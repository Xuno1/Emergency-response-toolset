#!/bin/bash
./rebuild.sh
nroff -man guymager.1 | less

