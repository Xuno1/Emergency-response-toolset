#!/bin/bash

sudo /opt/sysmon/sysmon -u > /dev/null
sudo service auditd stop
sudo service auoms stop
killall execPerSec
sudo auditctl -D > /dev/null

sudo auditbeat -c ./auditbeat.yml &
sleep 1

auditbeatpid=`ps -ef | grep auditbeat | grep -v sudo | grep -v grep | awk '{print $2}'`
journaldpid=`ps -ef | grep systemd-journald | grep -v grep | awk '{print $2}'`
kauditdpid=`ps -ef | grep kauditd | grep -v grep | awk '{print $2}'`

for i in 100 200 400 800 1600; do
	execPerSec/execPerSec $i 50 &
	sleep 10
	RES=`pidstat -h -u -p $auditbeatpid -p $journaldpid -p $kauditdpid 30 1 | tail -n3 | awk '{print $8}'`
	CPU=`echo $RES | awk '{c=0;for(i=1;i<=NF;++i){c+=$i};print c}'`
	echo "auditbeat,$i,$CPU"
	killall execPerSec
done

sudo killall auditbeat
sudo auditctl -D > /dev/null

