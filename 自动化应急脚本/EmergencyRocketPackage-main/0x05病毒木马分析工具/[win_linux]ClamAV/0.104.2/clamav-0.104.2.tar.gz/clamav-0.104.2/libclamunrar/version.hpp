#define RARVER_MAJOR     6
#define RARVER_MINOR     2
#define RARVER_BETA      0
#define RARVER_DAY      11
#define RARVER_MONTH     6
#define RARVER_YEAR   2021
